import pandas as pd
from transformers import GPT2Tokenizer, GPT2LMHeadModel
import torch
import numpy as np
from Levenshtein import distance as levenshtein_distance
from tqdm import tqdm

train_data = pd.read_json('training.jsonl', lines=True)
val_data = pd.read_json('val.jsonl', lines=True)
test_data = pd.read_json('test.jsonl', lines=True)

def combine_text(data):
    return data['postText'].apply(lambda x: x[0]) + " " + data['targetTitle'] + " " + data['targetParagraphs'].apply(lambda x: " ".join(x))

train_data['text'] = combine_text(train_data)
val_data['text'] = combine_text(val_data)
test_data['text'] = combine_text(test_data)


tokenizer = GPT2Tokenizer.from_pretrained('gpt2', cache_dir='D:/transformers_cache')
model = GPT2LMHeadModel.from_pretrained('gpt2', cache_dir='D:/transformers_cache')


def generate_spoilers(texts, num_generations=5):
    all_spoilers = []
    for text in tqdm(texts):
        inputs = tokenizer.encode(text, return_tensors='pt', max_length=512, truncation=True)
        spoilers = []
        for _ in range(num_generations):
            outputs = model.generate(inputs, max_length=50, num_return_sequences=1, do_sample=True, top_k=50)
            spoiler = tokenizer.decode(outputs[0], skip_special_tokens=True)
            spoilers.append(spoiler)
        all_spoilers.append(spoilers)
    return all_spoilers


test_spoilers = generate_spoilers(test_data['text'].tolist())


def select_best_spoiler(spoilers):
    best_spoilers = []
    for spoiler_set in spoilers:
        distances = [levenshtein_distance(spoiler_set[i], spoiler_set[j]) for i in range(len(spoiler_set)) for j in range(i + 1, len(spoiler_set))]
        avg_distances = np.mean(distances)
        best_spoiler = spoiler_set[np.argmin(avg_distances)]
        best_spoilers.append(best_spoiler)
    return best_spoilers


best_spoilers = select_best_spoiler(test_spoilers)


submission = pd.DataFrame({'id': test_data['id'], 'spoiler': best_spoilers})
submission.to_csv('prediction_task2.csv', index=False)
