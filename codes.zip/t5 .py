import pandas as pd
from transformers import T5Tokenizer, T5EncoderModel
import torch
import numpy as np


train_data = pd.read_json('training.jsonl', lines=True)
val_data = pd.read_json('val.jsonl', lines=True)


print(train_data.head())


train_data['text'] = train_data['postText'].apply(lambda x: x[0]) + " " + train_data['targetTitle'] + " " + train_data['targetParagraphs'].apply(lambda x: " ".join(x))
val_data['text'] = val_data['postText'].apply(lambda x: x[0]) + " " + val_data['targetTitle'] + " " + val_data['targetParagraphs'].apply(lambda x: " ".join(x))


train_data['tags'] = train_data['tags'].apply(lambda x: x[0] if isinstance(x, list) else x)
val_data['tags'] = val_data['tags'].apply(lambda x: x[0] if isinstance(x, list) else x)


tokenizer = T5Tokenizer.from_pretrained('t5-small', cache_dir='D:/transformers_cache')
model = T5EncoderModel.from_pretrained('t5-small', cache_dir='D:/transformers_cache')


def encode_texts(texts, batch_size=32):
    all_embeddings = []
    for i in range(0, len(texts), batch_size):
        batch_texts = texts[i:i+batch_size]
        inputs = tokenizer(batch_texts, return_tensors='pt', padding=True, truncation=True, max_length=512)
        with torch.no_grad():
            outputs = model(**inputs)
        embeddings = outputs.last_hidden_state[:, 0, :].numpy()
        all_embeddings.append(embeddings)
    return np.vstack(all_embeddings)

X_train = encode_texts(train_data['text'].tolist())
X_val = encode_texts(val_data['text'].tolist())


from sklearn.preprocessing import LabelEncoder
label_encoder = LabelEncoder()
y_train = label_encoder.fit_transform(train_data['tags'])
y_val = label_encoder.transform(val_data['tags'])

import xgboost as xgb
from sklearn.model_selection import GridSearchCV
from sklearn.metrics import accuracy_score


xgb_model = xgb.XGBClassifier(use_label_encoder=False, eval_metric='mlogloss')


param_grid = {
    'n_estimators': [100, 200],
    'max_depth': [4, 6, 8],
    'learning_rate': [0.01, 0.1, 0.2],
    'subsample': [0.8, 1.0]
}


grid_search = GridSearchCV(estimator=xgb_model, param_grid=param_grid, cv=3, n_jobs=-1, verbose=2)
grid_search.fit(X_train, y_train)


best_params = grid_search.best_params_
print(f'Best Parameters: {best_params}')


best_xgb_model = xgb.XGBClassifier(**best_params, use_label_encoder=False, eval_metric='mlogloss')
best_xgb_model.fit(X_train, y_train)


y_val_pred = best_xgb_model.predict(X_val)
val_accuracy = accuracy_score(y_val, y_val_pred)
print(f'Validation Accuracy: {val_accuracy}')


test_data = pd.read_json('test.jsonl', lines=True)


test_data['text'] = test_data['postText'].apply(lambda x: x[0]) + " " + test_data['targetTitle'] + " " + test_data['targetParagraphs'].apply(lambda x: " ".join(x))


X_test = encode_texts(test_data['text'].tolist())


y_test_pred = best_xgb_model.predict(X_test)
predictions = label_encoder.inverse_transform(y_test_pred)


submission = pd.DataFrame({'id': test_data['id'], 'spoilerType': predictions})
submission.to_csv('prediction_task1.csv', index=False)
